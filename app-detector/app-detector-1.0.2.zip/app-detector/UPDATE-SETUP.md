# App Detector Plugin - Update System Setup

This guide explains how to set up automatic updates for the App Detector plugin using the Plugin Update Checker library.

## 🚀 Overview

The Plugin Update Checker allows you to distribute your plugin from your own hosting while still providing automatic updates to your users. This is based on the [Plugin Update Checker library](https://github.com/YahnisElsts/plugin-update-checker) by Yahnis Elsts.

## 📁 File Structure

```
app-detector/
├── app-detector.php              # Main plugin file (updated)
├── app-detector.js              # Frontend JavaScript
├── admin.js                     # Admin JavaScript
├── README.md                    # Plugin documentation
├── plugin-update-checker/       # Update checker library
│   ├── plugin-update-checker.php
│   └── Puc/
│       └── v5/
│           ├── Factory.php
│           ├── Autoloader.php
│           ├── plugin/
│           │   └── updatechecker.php
│           └── theme/
│               └── updatechecker.php
└── update-server-example/       # Example update server files
    └── info.json
```

## 🔧 Setup Instructions

### 1. Update Your Plugin

The main plugin file (`app-detector.php`) has been updated to include the update checker. The key changes are:

- Added update checker initialization
- Integrated with WordPress update system
- Added custom query and download filters

### 2. Configure Your Update Server

You need to host the update information on your server. Create a directory structure like this:

```
your-domain.com/
└── app-detector-updates/
    ├── info.json                 # Update metadata
    ├── app-detector-1.0.1.zip   # Plugin package
    ├── app-detector-1.0.2.zip   # Newer version
    └── ...                      # Future versions
```

### 3. Update the Metadata URL

In `app-detector.php`, line 47, update the metadata URL:

```php
$this->updateChecker = Puc_v5_Factory::buildUpdateChecker(
    'https://your-domain.com/app-detector-updates/info.json', // Replace with your actual URL
    __FILE__,
    'app-detector'
);
```

### 4. Create Your Update Server

#### Option A: Static JSON File (Recommended)

Create a `info.json` file on your server with the following structure:

```json
{
    "version": "1.0.2",
    "download_url": "https://your-domain.com/app-detector-updates/app-detector-1.0.2.zip",
    "requires": "5.0",
    "requires_php": "7.4",
    "tested": "6.4",
    "last_updated": "2025-01-15",
    "homepage": "https://fika.nu/app-detector",
    "sections": {
        "description": "A WordPress plugin that detects mobile devices...",
        "installation": "1. Upload the plugin files...",
        "changelog": "## Version 1.0.2\n- Fixed mobile device detection...",
        "screenshots": {
            "1": "https://your-domain.com/app-detector-updates/screenshot-1.png"
        }
    },
    "banners": {
        "high": "https://your-domain.com/app-detector-updates/banner-772x250.png",
        "low": "https://your-domain.com/app-detector-updates/banner-154x500.png"
    }
}
```

#### Option B: Dynamic PHP Script

Create a `info.php` file that generates the JSON dynamically:

```php
<?php
header('Content-Type: application/json');

$current_version = '1.0.2';
$installed_version = $_GET['installed_version'] ?? '0.0.0';

// Only show update if newer version is available
if (version_compare($current_version, $installed_version, '>')) {
    echo json_encode([
        'version' => $current_version,
        'download_url' => 'https://your-domain.com/app-detector-updates/app-detector-' . $current_version . '.zip',
        'requires' => '5.0',
        'requires_php' => '7.4',
        'tested' => '6.4',
        'last_updated' => '2025-01-15',
        'homepage' => 'https://fika.nu/app-detector',
        'sections' => [
            'description' => 'A WordPress plugin that detects mobile devices...',
            'installation' => '1. Upload the plugin files...',
            'changelog' => '## Version ' . $current_version . "\n- Fixed mobile device detection..."
        ]
    ]);
} else {
    echo json_encode(['version' => $installed_version]);
}
?>
```

### 5. Create Plugin Packages

When you release a new version:

1. **Update the version number** in `app-detector.php` (line 5)
2. **Update the version constant** in `app-detector.php` (line 24)
3. **Create a ZIP file** of your plugin directory
4. **Upload the ZIP** to your update server
5. **Update the `info.json`** file with the new version information

Example ZIP structure:
```
app-detector-1.0.2.zip
├── app-detector.php
├── app-detector.js
├── admin.js
├── README.md
└── plugin-update-checker/
    └── ...
```

### 6. Test the Update System

1. Install the plugin on a test WordPress site
2. Update the `info.json` file with a newer version
3. Go to WordPress Admin → Plugins
4. You should see an update notification
5. Test the update process

## 🔒 Security Considerations

### Authentication (Optional)

If you want to restrict access to updates, you can implement authentication:

```php
// In app-detector.php
$this->updateChecker->setAuthentication('your-secret-token');

// In your update server
if ($_GET['token'] !== 'your-secret-token') {
    http_response_code(403);
    exit;
}
```

### HTTPS

Always use HTTPS for your update server to prevent man-in-the-middle attacks.

### File Permissions

Ensure your update server files are readable but not writable by unauthorized users.

## 📊 Monitoring

The update checker sends the following information with each request:

- `installed_version`: Current plugin version
- `php`: PHP version
- `locale`: WordPress locale
- `site_url`: Site URL (custom)
- `wp_version`: WordPress version (custom)
- `plugin_version`: Plugin version (custom)

You can use this information to:
- Track which versions are installed
- Provide different updates based on PHP/WordPress versions
- Monitor plugin usage

## 🐛 Troubleshooting

### Common Issues

1. **Updates not showing**: Check that your `info.json` is accessible and valid JSON
2. **Download fails**: Ensure your ZIP file is accessible and properly formatted
3. **Version comparison issues**: Make sure version numbers follow semantic versioning

### Debug Mode

Enable debug mode by adding this to your plugin:

```php
$this->updateChecker->debugMode = true;
```

### Manual Update Check

Users can manually check for updates by clicking the "Check for updates" link in the plugin row.

## 📚 Additional Resources

- [Plugin Update Checker Documentation](https://github.com/YahnisElsts/plugin-update-checker)
- [WordPress Plugin Development Handbook](https://developer.wordpress.org/plugins/)
- [WordPress Update API](https://developer.wordpress.org/reference/functions/wp_update_plugins/)

## 🤝 Support

For technical support and questions, please contact: **tech@fika.nu**

---

**Copyright © 2025 FikaBytes, made by Marketing and Apps by Silfver** 