(function() {
    'use strict';
    
    // Check if we're on a mobile device
    async function isMobileDevice() {
        try {
            const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            console.log('App Detector - User Agent:', navigator.userAgent);
            console.log('App Detector - Is Mobile Device:', isMobile);
            return isMobile;
        } catch (error) {
            console.error('App Detector - Error detecting mobile device:', error);
            return false;
        }
    }
    
    // Check if we're on iOS
    async function isIOS() {
        try {
            const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent);
            console.log('App Detector - Is iOS:', isIOSDevice);
            return isIOSDevice;
        } catch (error) {
            console.error('App Detector - Error detecting iOS:', error);
            return false;
        }
    }
    
    // Check if we're on Android
    async function isAndroid() {
        try {
            const isAndroidDevice = /Android/.test(navigator.userAgent);
            console.log('App Detector - Is Android:', isAndroidDevice);
            return isAndroidDevice;
        } catch (error) {
            console.error('App Detector - Error detecting Android:', error);
            return false;
        }
    }
    
    // Check if popup has been dismissed in this session
    async function isPopupDismissed() {
        try {
            const dismissed = sessionStorage.getItem('appDetectorPopupDismissed') === 'true';
            console.log('App Detector - Popup Dismissed:', dismissed);
            return dismissed;
        } catch (error) {
            console.error('App Detector - Error checking popup dismissal:', error);
            return false;
        }
    }
    
    // Mark popup as dismissed
    async function markPopupDismissed() {
        try {
            sessionStorage.setItem('appDetectorPopupDismissed', 'true');
            console.log('App Detector - Popup marked as dismissed');
        } catch (error) {
            console.error('App Detector - Error marking popup as dismissed:', error);
        }
    }
    
    // Get translation text
    function getTranslation(key) {
        try {
            if (window.appDetectorConfig && window.appDetectorConfig.translations) {
                return window.appDetectorConfig.translations[key] || key;
            }
            return key;
        } catch (error) {
            console.error('App Detector - Error getting translation:', error);
            return key;
        }
    }
    
    // Check if current language is RTL (Arabic)
    function isRTL() {
        try {
            return window.appDetectorConfig && window.appDetectorConfig.language === 'ar';
        } catch (error) {
            console.error('App Detector - Error checking RTL:', error);
            return false;
        }
    }
    
    // Try to open the app and detect if it's installed
    async function tryOpenApp(appUri, storeUrl) {
        return new Promise((resolve) => {
            try {
                console.log('App Detector - Trying to open app with URI:', appUri);
                
                let hasApp = false;
                let startTime = Date.now();
                
                // Listen for page visibility change (indicates app opened)
                const visibilityHandler = function() {
                    if (document.hidden) {
                        hasApp = true;
                        console.log('App Detector - App is installed (visibility change)');
                        document.removeEventListener('visibilitychange', visibilityHandler);
                        resolve({ hasApp: true, opened: true });
                    }
                };
                
                document.addEventListener('visibilitychange', visibilityHandler);
                
                // Try to open the app
                try {
                    window.location.href = appUri;
                } catch (e) {
                    console.log('App Detector - Error opening app URI:', e);
                }
                
                // Set a timeout to detect if the app opens
                setTimeout(function() {
                    const timeElapsed = Date.now() - startTime;
                    hasApp = false;
                    console.log('App Detector - App not installed (timeout after', timeElapsed, 'ms)');
                    document.removeEventListener('visibilitychange', visibilityHandler);
                    
                    // If app didn't open, redirect to store
                    if (!hasApp) {
                        console.log('App Detector - Redirecting to app store:', storeUrl);
                        window.open(storeUrl, '_blank');
                    }
                    
                    resolve({ hasApp: false, opened: false });
                }, 1500);
                
            } catch (error) {
                console.error('App Detector - Error in tryOpenApp:', error);
                resolve({ hasApp: false, opened: false });
            }
        });
    }
    
    // Create and show the popup
    async function showPopup() {
        try {
            console.log('App Detector - Showing popup');
            
            // Remove existing popup if any
            const existingPopup = document.getElementById('app-detector-popup');
            if (existingPopup) {
                existingPopup.remove();
            }
            
            const isRTLText = isRTL();
            
            // Create popup container
            const popup = document.createElement('div');
            popup.id = 'app-detector-popup';
            popup.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 999999;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            `;
            
            // Create popup content
            const popupContent = document.createElement('div');
            popupContent.style.cssText = `
                background: white;
                border-radius: 12px;
                padding: 24px;
                max-width: 320px;
                width: 90%;
                text-align: ${isRTLText ? 'right' : 'center'};
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
                direction: ${isRTLText ? 'rtl' : 'ltr'};
            `;
            
            // Create title
            const title = document.createElement('h3');
            title.style.cssText = `
                margin: 0 0 16px 0;
                font-size: 18px;
                font-weight: 600;
                color: #333;
                text-align: ${isRTLText ? 'right' : 'center'};
            `;
            title.textContent = getTranslation('popup_title');
            
            // Create description
            const description = document.createElement('p');
            description.style.cssText = `
                margin: 0 0 20px 0;
                font-size: 14px;
                color: #666;
                line-height: 1.4;
                text-align: ${isRTLText ? 'right' : 'center'};
            `;
            description.textContent = getTranslation('popup_description');
            
            // Create button container
            const buttonContainer = document.createElement('div');
            buttonContainer.style.cssText = `
                display: flex;
                gap: 12px;
                justify-content: center;
                flex-direction: column;
            `;
            
            // Open App button
            const openAppBtn = document.createElement('button');
            openAppBtn.style.cssText = `
                background: #007AFF;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                width: 100%;
                direction: ${isRTLText ? 'rtl' : 'ltr'};
            `;
            openAppBtn.textContent = getTranslation('open_app');
            openAppBtn.onclick = async function() {
                try {
                    console.log('App Detector - User clicked Open App');
                    
                    // Get the appropriate URI scheme and store URL based on platform
                    let appUri = '';
                    let storeUrl = '';
                    
                    const isIOSDevice = await isIOS();
                    const isAndroidDevice = await isAndroid();
                    
                    if (isIOSDevice) {
                        appUri = window.appDetectorConfig.iosUri;
                        storeUrl = window.appDetectorConfig.appleStore;
                        console.log('App Detector - iOS detected. URI:', appUri, 'Store:', storeUrl);
                    } else if (isAndroidDevice) {
                        appUri = window.appDetectorConfig.androidUri;
                        storeUrl = window.appDetectorConfig.googlePlay;
                        console.log('App Detector - Android detected. URI:', appUri, 'Store:', storeUrl);
                    } else {
                        console.log('App Detector - Platform not detected, using default');
                        appUri = window.appDetectorConfig.androidUri || window.appDetectorConfig.iosUri;
                        storeUrl = window.appDetectorConfig.googlePlay || window.appDetectorConfig.appleStore;
                    }
                    
                    if (!appUri) {
                        console.log('App Detector - No URI scheme found, opening store directly');
                        window.open(storeUrl, '_blank');
                        popup.remove();
                        return;
                    }
                    
                    // Try to open the app
                    const result = await tryOpenApp(appUri, storeUrl);
                    console.log('App Detector - App open result:', result);
                    
                    // Close popup
                    popup.remove();
                    
                } catch (error) {
                    console.error('App Detector - Error opening app:', error);
                    popup.remove();
                }
            };
            
            // Continue on Web button
            const continueWebBtn = document.createElement('button');
            continueWebBtn.style.cssText = `
                background: #F2F2F7;
                color: #333;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 14px;
                font-weight: 500;
                cursor: pointer;
                width: 100%;
                direction: ${isRTLText ? 'rtl' : 'ltr'};
            `;
            continueWebBtn.textContent = getTranslation('continue_web');
            continueWebBtn.onclick = async function() {
                try {
                    console.log('App Detector - User clicked Continue on Web');
                    await markPopupDismissed();
                    popup.remove();
                } catch (error) {
                    console.error('App Detector - Error continuing on web:', error);
                    popup.remove();
                }
            };
            
            // Close button
            const closeBtn = document.createElement('button');
            closeBtn.style.cssText = `
                background: transparent;
                color: #666;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 400;
                cursor: pointer;
                width: 100%;
                margin-top: 8px;
                direction: ${isRTLText ? 'rtl' : 'ltr'};
            `;
            closeBtn.textContent = getTranslation('close');
            closeBtn.onclick = async function() {
                try {
                    await markPopupDismissed();
                    popup.remove();
                } catch (error) {
                    console.error('App Detector - Error closing popup:', error);
                    popup.remove();
                }
            };
            
            buttonContainer.appendChild(openAppBtn);
            buttonContainer.appendChild(continueWebBtn);
            // buttonContainer.appendChild(closeBtn);
            
            // Assemble popup
            popupContent.appendChild(title);
            popupContent.appendChild(description);
            popupContent.appendChild(buttonContainer);
            popup.appendChild(popupContent);
            
            // Add to page
            document.body.appendChild(popup);
            
            // Close popup when clicking outside
            popup.addEventListener('click', async function(e) {
                if (e.target === popup) {
                    try {
                        await markPopupDismissed();
                        popup.remove();
                    } catch (error) {
                        console.error('App Detector - Error closing popup:', error);
                        popup.remove();
                    }
                }
            });
        } catch (error) {
            console.error('App Detector - Error showing popup:', error);
        }
    }
    
    // Main function to handle app detection
    async function handleAppDetection() {
        try {
            console.log('App Detector - Starting detection...');
            
            // Only run on mobile devices
            const isMobile = await isMobileDevice();
            if (!isMobile) {
                console.log('App Detector - Not a mobile device, stopping detection');
                return;
            }
            
            // Check if popup has been dismissed in this session
            const isDismissed = await isPopupDismissed();
            if (isDismissed) {
                console.log('App Detector - Popup dismissed in this session, stopping detection');
                return;
            }
            
            // Check if we have the required configuration
            if (!window.appDetectorConfig) {
                console.log('App Detector - No configuration found, stopping detection');
                return;
            }
            
            console.log('App Detector - Configuration found:', window.appDetectorConfig);
            
            // Show popup after a short delay to ensure page is loaded
            setTimeout(async function() {
                try {
                    await showPopup();
                } catch (error) {
                    console.error('App Detector - Error showing popup:', error);
                }
            }, 1000);
            
        } catch (error) {
            console.error('App Detector - Error in handleAppDetection:', error);
        }
    }
    
    // Run when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            handleAppDetection().catch(error => {
                console.error('App Detector - Error in DOMContentLoaded:', error);
            });
        });
    } else {
        handleAppDetection().catch(error => {
            console.error('App Detector - Error in immediate execution:', error);
        });
    }
    
})();