<?php
/**
 * Plugin Update Checker Autoloader
 * 
 * @package PluginUpdateChecker
 * @version 5.6
 */

if (!class_exists('Puc_v5_Autoloader')) {
    class Puc_v5_Autoloader {
        private $prefix = 'Puc_v5_';
        private $baseDir;
        private $libraryDir;
        
        public function __construct($baseDir = null) {
            $this->baseDir = $baseDir ? $baseDir : dirname(__FILE__);
            $this->libraryDir = $this->baseDir . '/';
            
            spl_autoload_register(array($this, 'autoload'));
        }
        
        public function autoload($className) {
            // Only handle classes with our prefix
            if (strpos($className, $this->prefix) !== 0) {
                return;
            }
            
            $path = $this->getClassPath($className);
            if (file_exists($path)) {
                require_once $path;
            }
        }
        
        private function getClassPath($className) {
            // Remove the prefix
            $relativeClass = substr($className, strlen($this->prefix));
            
            // Convert class name to file path
            $path = str_replace('_', '/', $relativeClass);
            $path = strtolower($path);
            
            return $this->libraryDir . $path . '.php';
        }
    }
} 