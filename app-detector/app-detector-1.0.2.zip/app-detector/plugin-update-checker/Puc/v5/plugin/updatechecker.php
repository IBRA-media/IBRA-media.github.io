<?php
/**
 * Plugin Update Checker
 * 
 * @package PluginUpdateChecker
 * @version 5.6
 */

if (!class_exists('Puc_v5_Plugin_UpdateChecker')) {
    class Puc_v5_Plugin_UpdateChecker {
        public $metadataUrl = '';
        public $pluginAbsolutePath = '';
        public $pluginFile = '';
        public $slug = '';
        public $checkPeriod = 12;
        public $optionName = '';
        public $debugMode = false;
        
        private $cronHook = null;
        private $manualCheckHook = null;
        private $option = null;
        
        public function __construct($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '') {
            $this->metadataUrl = $metadataUrl;
            $this->pluginAbsolutePath = $pluginFile;
            $this->pluginFile = plugin_basename($pluginFile);
            $this->slug = $slug;
            $this->checkPeriod = $checkPeriod;
            $this->optionName = $optionName;
            
            // Set up the WordPress hooks
            $this->installHooks();
        }
        
        public function installHooks() {
            // Set up the periodic update checks
            $this->cronHook = 'check_plugin_updates-' . $this->slug;
            if (!has_action($this->cronHook)) {
                add_action($this->cronHook, array($this, 'checkForUpdates'));
            }
            
            // Manual update check
            $this->manualCheckHook = 'manual_check_updates-' . $this->slug;
            add_action($this->manualCheckHook, array($this, 'checkForUpdates'));
            
            // WordPress update hooks
            add_filter('pre_set_site_transient_update_plugins', array($this, 'injectUpdate'));
            add_filter('site_transient_update_plugins', array($this, 'injectUpdate'));
            add_filter('pre_set_transient_update_plugins', array($this, 'injectUpdate'));
            add_filter('transient_update_plugins', array($this, 'injectUpdate'));
            
            // Add "Check for updates" link to the plugin row
            add_filter('plugin_row_meta', array($this, 'addCheckForUpdatesLink'), 10, 2);
            
            // Add admin notice for update availability
            add_action('admin_notices', array($this, 'displayUpdateAdminNotice'));
        }
        
        public function checkForUpdates() {
            $installedVersion = $this->getInstalledVersion();
            $update = $this->requestUpdate();
            
            if ($update !== null) {
                $this->updateOption($update);
            }
            
            return $update;
        }
        
        public function requestUpdate() {
            $installedVersion = $this->getInstalledVersion();
            $update = null;
            
            // Get the remote metadata
            $remoteMetadata = $this->requestMetadata();
            if ($remoteMetadata === null) {
                return null;
            }
            
            // Parse the metadata
            $update = $this->parseMetadata($remoteMetadata);
            
            return $update;
        }
        
        protected function requestMetadata() {
            $url = $this->metadataUrl;
            
            // Add query arguments
            $url = add_query_arg(array(
                'installed_version' => $this->getInstalledVersion(),
                'php' => phpversion(),
                'locale' => get_locale(),
            ), $url);
            
            $response = wp_remote_get($url, array(
                'timeout' => 10,
                'headers' => array(
                    'Accept' => 'application/json',
                ),
            ));
            
            if (is_wp_error($response)) {
                return null;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (empty($data) || !is_array($data)) {
                return null;
            }
            
            return $data;
        }
        
        protected function parseMetadata($metadata) {
            if (!isset($metadata['version'])) {
                return null;
            }
            
            $installedVersion = $this->getInstalledVersion();
            $remoteVersion = $metadata['version'];
            
            // Check if the remote version is newer
            if (version_compare($remoteVersion, $installedVersion, '>')) {
                $update = new stdClass();
                $update->slug = $this->slug;
                $update->new_version = $remoteVersion;
                $update->url = isset($metadata['homepage']) ? $metadata['homepage'] : '';
                $update->package = isset($metadata['download_url']) ? $metadata['download_url'] : '';
                $update->requires = isset($metadata['requires']) ? $metadata['requires'] : '';
                $update->requires_php = isset($metadata['requires_php']) ? $metadata['requires_php'] : '';
                $update->tested = isset($metadata['tested']) ? $metadata['tested'] : '';
                $update->last_updated = isset($metadata['last_updated']) ? $metadata['last_updated'] : '';
                $update->sections = isset($metadata['sections']) ? $metadata['sections'] : array();
                $update->banners = isset($metadata['banners']) ? $metadata['banners'] : array();
                
                return $update;
            }
            
            return null;
        }
        
        public function injectUpdate($updates) {
            if (!is_object($updates)) {
                $updates = new stdClass();
            }
            
            if (!isset($updates->response)) {
                $updates->response = array();
            }
            
            $update = $this->getUpdate();
            if ($update !== null) {
                $updates->response[$this->pluginFile] = $update;
            }
            
            return $updates;
        }
        
        public function getUpdate() {
            $update = $this->getOption();
            
            if (empty($update)) {
                return null;
            }
            
            return $update;
        }
        
        protected function getOption() {
            if ($this->option === null) {
                $this->option = get_site_option($this->optionName, null);
            }
            return $this->option;
        }
        
        protected function updateOption($value) {
            $this->option = $value;
            return update_site_option($this->optionName, $value);
        }
        
        protected function getInstalledVersion() {
            if (!function_exists('get_plugin_data')) {
                require_once(ABSPATH . 'wp-admin/includes/plugin.php');
            }
            
            $pluginData = get_plugin_data($this->pluginAbsolutePath, false, false);
            return isset($pluginData['Version']) ? $pluginData['Version'] : '';
        }
        
        public function addCheckForUpdatesLink($links, $file) {
            if ($file === $this->pluginFile) {
                $link = sprintf(
                    '<a href="%s">%s</a>',
                    wp_nonce_url(
                        add_query_arg(
                            array(
                                'action' => $this->manualCheckHook,
                                'plugin' => $this->slug,
                            ),
                            admin_url('admin-ajax.php')
                        ),
                        'manual-update-check'
                    ),
                    __('Check for updates', 'app-detector')
                );
                $links[] = $link;
            }
            return $links;
        }
        
        public function displayUpdateAdminNotice() {
            $update = $this->getUpdate();
            if ($update === null) {
                return;
            }
            
            $message = sprintf(
                __('There is a new version of %s available. <a href="%s">View version %s details</a> or <a href="%s">update now</a>.', 'app-detector'),
                $this->slug,
                admin_url('plugins.php?action=upgrade-plugin&plugin=' . urlencode($this->pluginFile)),
                $update->new_version,
                wp_nonce_url(
                    admin_url('update.php?action=upgrade-plugin&plugin=' . urlencode($this->pluginFile)),
                    'upgrade-plugin_' . $this->pluginFile
                )
            );
            
            printf(
                '<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
                $message
            );
        }
        
        public function setAuthentication($credentials) {
            // This can be implemented for private repositories
            $this->authentication = $credentials;
        }
        
        public function addQueryArgFilter($callback) {
            // This can be implemented to add custom query arguments
            $this->queryArgFilters[] = $callback;
        }
        
        public function addDownloadFilter($callback) {
            // This can be implemented to modify download URLs
            $this->downloadFilters[] = $callback;
        }
    }
} 