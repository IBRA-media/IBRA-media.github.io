<?php
/**
 * Theme Update Checker
 * 
 * @package PluginUpdateChecker
 * @version 5.6
 */

if (!class_exists('Puc_v5_Theme_UpdateChecker')) {
    class Puc_v5_Theme_UpdateChecker extends Puc_v5_Plugin_UpdateChecker {
        public function __construct($metadataUrl, $themeFile, $slug = '', $checkPeriod = 12, $optionName = '') {
            parent::__construct($metadataUrl, $themeFile, $slug, $checkPeriod, $optionName);
        }
        
        public function installHooks() {
            // Set up the periodic update checks
            $this->cronHook = 'check_theme_updates-' . $this->slug;
            if (!has_action($this->cronHook)) {
                add_action($this->cronHook, array($this, 'checkForUpdates'));
            }
            
            // Manual update check
            $this->manualCheckHook = 'manual_check_theme_updates-' . $this->slug;
            add_action($this->manualCheckHook, array($this, 'checkForUpdates'));
            
            // WordPress update hooks for themes
            add_filter('pre_set_site_transient_update_themes', array($this, 'injectUpdate'));
            add_filter('site_transient_update_themes', array($this, 'injectUpdate'));
            add_filter('pre_set_transient_update_themes', array($this, 'injectUpdate'));
            add_filter('transient_update_themes', array($this, 'injectUpdate'));
            
            // Add "Check for updates" link to the theme row
            add_filter('theme_row_meta', array($this, 'addCheckForUpdatesLink'), 10, 2);
            
            // Add admin notice for update availability
            add_action('admin_notices', array($this, 'displayUpdateAdminNotice'));
        }
        
        public function injectUpdate($updates) {
            if (!is_object($updates)) {
                $updates = new stdClass();
            }
            
            if (!isset($updates->response)) {
                $updates->response = array();
            }
            
            $update = $this->getUpdate();
            if ($update !== null) {
                $updates->response[$this->slug] = $update;
            }
            
            return $updates;
        }
        
        protected function getInstalledVersion() {
            $theme = wp_get_theme($this->slug);
            return $theme->get('Version');
        }
        
        public function addCheckForUpdatesLink($links, $theme) {
            if ($theme->get_stylesheet() === $this->slug) {
                $link = sprintf(
                    '<a href="%s">%s</a>',
                    wp_nonce_url(
                        add_query_arg(
                            array(
                                'action' => $this->manualCheckHook,
                                'theme' => $this->slug,
                            ),
                            admin_url('admin-ajax.php')
                        ),
                        'manual-update-check'
                    ),
                    __('Check for updates', 'app-detector')
                );
                $links[] = $link;
            }
            return $links;
        }
        
        public function displayUpdateAdminNotice() {
            $update = $this->getUpdate();
            if ($update === null) {
                return;
            }
            
            $message = sprintf(
                __('There is a new version of %s theme available. <a href="%s">View version %s details</a> or <a href="%s">update now</a>.', 'app-detector'),
                $this->slug,
                admin_url('themes.php?action=upgrade-theme&theme=' . urlencode($this->slug)),
                $update->new_version,
                wp_nonce_url(
                    admin_url('update.php?action=upgrade-theme&theme=' . urlencode($this->slug)),
                    'upgrade-theme_' . $this->slug
                )
            );
            
            printf(
                '<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
                $message
            );
        }
    }
} 