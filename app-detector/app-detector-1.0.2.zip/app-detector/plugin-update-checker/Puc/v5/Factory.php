<?php
/**
 * Plugin Update Checker Factory
 * 
 * @package PluginUpdateChecker
 * @version 5.6
 */

if (!class_exists('Puc_v5_Factory')) {
    class Puc_v5_Factory {
        /**
         * Create a new update checker instance.
         *
         * @param string $metadataUrl The URL of the metadata file.
         * @param string $pluginFile The path to the plugin file.
         * @param string $slug The plugin slug.
         * @param int $checkPeriod How often to check for updates (in hours).
         * @param string $optionName Where to store the update info.
         * @return Puc_v5_Plugin_UpdateChecker
         */
        public static function buildUpdateChecker($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '') {
            if (empty($slug)) {
                $slug = basename($pluginFile, '.php');
            }
            
            if (empty($optionName)) {
                $optionName = 'external_updates-' . $slug;
            }
            
            return new Puc_v5_Plugin_UpdateChecker($metadataUrl, $pluginFile, $slug, $checkPeriod, $optionName);
        }
        
        /**
         * Create a new theme update checker instance.
         *
         * @param string $metadataUrl The URL of the metadata file.
         * @param string $themeFile The path to the theme file.
         * @param string $slug The theme slug.
         * @param int $checkPeriod How often to check for updates (in hours).
         * @param string $optionName Where to store the update info.
         * @return Puc_v5_Theme_UpdateChecker
         */
        public static function buildThemeUpdateChecker($metadataUrl, $themeFile, $slug = '', $checkPeriod = 12, $optionName = '') {
            if (empty($slug)) {
                $slug = basename($themeFile, '.css');
            }
            
            if (empty($optionName)) {
                $optionName = 'external_updates-' . $slug;
            }
            
            return new Puc_v5_Theme_UpdateChecker($metadataUrl, $themeFile, $slug, $checkPeriod, $optionName);
        }
    }
} 