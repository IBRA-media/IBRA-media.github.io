<?php
/**
 * Plugin Update Checker v5.6
 * 
 * This file is part of the Plugin Update Checker library.
 * It's included in the App Detector plugin to enable automatic updates.
 * 
 * @link https://github.com/YahnisElsts/plugin-update-checker
 * @author Yahnis Elsts
 * @license MIT
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include the Plugin Update Checker library
require_once plugin_dir_path(__FILE__) . 'Puc/v5/Factory.php';
require_once plugin_dir_path(__FILE__) . 'Puc/v5/Autoloader.php';

// Initialize the autoloader
new Puc_v5_Autoloader();

// Create the update checker instance
function app_detector_initialize_update_checker() {
    // Only run in admin
    if (!is_admin()) {
        return;
    }
    
    // Initialize the update checker
    $updateChecker = Puc_v5_Factory::buildUpdateChecker(
        'https://your-domain.com/app-detector-updates/info.json', // Replace with your actual update server URL
        __FILE__,
        'app-detector'
    );
    
    // Optional: Set authentication if using private repository
    // $updateChecker->setAuthentication('your-token-here');
    
    // Optional: Set branch if using Git repository
    // $updateChecker->setBranch('main');
    
    // Optional: Add custom query arguments
    $updateChecker->addQueryArgFilter('app_detector_update_filter');
    
    // Optional: Add custom download filter
    $updateChecker->addDownloadFilter('app_detector_download_filter');
    
    return $updateChecker;
}

// Custom query argument filter
function app_detector_update_filter($queryArgs) {
    // Add any custom parameters you want to send with update requests
    $queryArgs['site_url'] = get_site_url();
    $queryArgs['wp_version'] = get_bloginfo('version');
    $queryArgs['plugin_version'] = APP_DETECTOR_VERSION;
    
    return $queryArgs;
}

// Custom download filter
function app_detector_download_filter($url, $args) {
    // You can modify the download URL or add authentication here
    return $url;
}

// Initialize the update checker
add_action('init', 'app_detector_initialize_update_checker'); 