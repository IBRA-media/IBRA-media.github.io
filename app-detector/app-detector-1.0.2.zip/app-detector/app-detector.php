<?php
/**
 * Plugin Name: App Detector
 * Description: Detects mobile devices and shows app store links or opens the app if installed
 * Version: 1.0.2
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Author: FikaBytes
 * Author URI: https://fika.nu
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: app-detector
 * Domain Path: /languages
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('APP_DETECTOR_VERSION', '1.0.2');
define('APP_DETECTOR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('APP_DETECTOR_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('APP_DETECTOR_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include the Plugin Update Checker
require_once plugin_dir_path(__FILE__) . 'plugin-update-checker/plugin-update-checker.php';

class AppDetector {
    
    private $version;
    private $updateChecker;
    
    public function __construct() {
        $this->version = APP_DETECTOR_VERSION;
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_head', array($this, 'inject_script'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
        
        // Add version check on admin pages
        add_action('admin_notices', array($this, 'check_version'));
        
        // Add AJAX handlers for update checker
        if (!get_option('app_detector_ajax_disabled', false)) {
            add_action('wp_ajax_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
            add_action('wp_ajax_nopriv_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        }
        
        // Initialize update checker
        $this->init_update_checker();
    }
    
    /**
     * Initialize the update checker
     */
    private function init_update_checker() {
        // Only run in admin
        if (!is_admin()) {
            return;
        }
        
        // Check if update checker is disabled
        if (defined('APP_DETECTOR_DISABLE_UPDATES') && APP_DETECTOR_DISABLE_UPDATES) {
            return;
        }
        
        // Check if updates are disabled via admin option
        if (get_option('app_detector_updates_disabled', false)) {
            return;
        }
        
        try {
            // Check if the update checker class exists
            if (!class_exists('Puc_v5_Factory')) {
                error_log('App Detector: Plugin Update Checker not found');
                return;
            }
            
            // Initialize the update checker with error handling
            $this->updateChecker = Puc_v5_Factory::buildUpdateChecker(
                'https://ibra-media.github.io/app-detector/info.json',
                __FILE__,
                'app-detector'
            );
            
            // Add custom query arguments
            if ($this->updateChecker) {
                $this->updateChecker->addQueryArgFilter(array($this, 'update_filter'));
                $this->updateChecker->addDownloadFilter(array($this, 'download_filter'));
                
                // Add error handling for update checks
                add_action('admin_notices', array($this, 'check_update_errors'));
                
                // Add filter to prevent empty responses
                add_filter('http_request_args', array($this, 'modify_http_request'), 10, 2);
            }
            
        } catch (Exception $e) {
            error_log('App Detector: Update checker initialization failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Custom query argument filter for update requests
     */
    public function update_filter($queryArgs) {
        // Add any custom parameters you want to send with update requests
        $queryArgs['site_url'] = get_site_url();
        $queryArgs['wp_version'] = get_bloginfo('version');
        $queryArgs['plugin_version'] = $this->version;
        $queryArgs['php_version'] = phpversion();
        $queryArgs['locale'] = get_locale();
        
        return $queryArgs;
    }
    
    /**
     * Custom download filter
     */
    public function download_filter($url, $args) {
        // You can modify the download URL or add authentication here
        return $url;
    }
    
    /**
     * Modify HTTP requests to prevent empty responses
     */
    public function modify_http_request($args, $url) {
        // Only modify requests to our update server
        if (strpos($url, 'ibra-media.github.io/app-detector') !== false) {
            $args['timeout'] = 15;
            $args['user-agent'] = 'WordPress/' . get_bloginfo('version') . '; ' . get_site_url();
        }
        return $args;
    }
    
    /**
     * Test update server connection
     */
    public function test_update_server() {
        $update_url = 'https://ibra-media.github.io/app-detector/info.json';
        
        $response = wp_remote_get($update_url, array(
            'timeout' => 10,
            'user-agent' => 'WordPress/' . get_bloginfo('version') . '; ' . get_site_url()
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code !== 200) {
            return array(
                'success' => false,
                'error' => 'HTTP Status: ' . $status_code,
                'body' => $body
            );
        }
        
        // Check if response is empty or just ()
        if (empty($body) || trim($body) === '()') {
            return array(
                'success' => false,
                'error' => 'Empty response from server',
                'body' => $body
            );
        }
        
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array(
                'success' => false,
                'error' => 'Invalid JSON response: ' . json_last_error_msg(),
                'body' => $body
            );
        }
        
        return array(
            'success' => true,
            'data' => $data,
            'status_code' => $status_code
        );
    }
    
    /**
     * Disable update checker temporarily
     */
    public function disable_updates() {
        // Store the current update checker state
        update_option('app_detector_updates_disabled', true);
        
        // Clear any cached update data
        delete_transient('puc_request_info_app-detector');
        delete_transient('puc_request_update_app-detector');
        
        // Remove update checker hooks if they exist
        if ($this->updateChecker) {
            remove_filter('http_request_args', array($this, 'modify_http_request'));
            $this->updateChecker = null;
        }
        
        return true;
    }
    
    /**
     * Enable update checker
     */
    public function enable_updates() {
        delete_option('app_detector_updates_disabled');
        
        // Re-initialize the update checker
        $this->init_update_checker();
        
        return true;
    }
    
    /**
     * Completely remove update checker hooks
     */
    public function remove_update_checker() {
        // Remove all update checker related hooks
        remove_action('wp_ajax_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        remove_action('wp_ajax_nopriv_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        remove_filter('http_request_args', array($this, 'modify_http_request'));
        
        // Clear update checker instance
        $this->updateChecker = null;
        
        // Clear cached data
        delete_transient('puc_request_info_app-detector');
        delete_transient('puc_request_update_app-detector');
        
        // Store removal state
        update_option('app_detector_update_checker_removed', true);
        
        return true;
    }
    
    /**
     * Disable AJAX handlers
     */
    public function disable_ajax_handlers() {
        // Remove AJAX handlers
        remove_action('wp_ajax_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        remove_action('wp_ajax_nopriv_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        
        // Store disabled state
        update_option('app_detector_ajax_disabled', true);
        
        return true;
    }
    
    /**
     * Enable AJAX handlers
     */
    public function enable_ajax_handlers() {
        // Re-add AJAX handlers
        add_action('wp_ajax_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        add_action('wp_ajax_nopriv_manual_check_updates-app-detector', array($this, 'handle_manual_update_check'));
        
        // Remove disabled state
        delete_option('app_detector_ajax_disabled');
        
        return true;
    }
    
    /**
     * Get available languages
     */
    public function get_available_languages() {
        return array(
            'en' => array(
                'name' => 'English',
                'native' => 'English'
            ),
            'ar' => array(
                'name' => 'Arabic',
                'native' => 'العربية'
            )
        );
    }
    
    /**
     * Get translations for a specific language
     */
    public function get_translations($language = 'en') {
        $translations = array(
            'en' => array(
                'popup_title' => 'Open App or Continue on Web',
                'popup_description' => 'Would you like to open our mobile app for the best experience, or continue browsing on the web?',
                'open_app' => 'Open App',
                'continue_web' => 'Continue on Web',
                'close' => 'Close'
            ),
            'ar' => array(
                'popup_title' => 'افتح التطبيق أو استمر على الويب',
                'popup_description' => 'هل تريد فتح تطبيقنا المحمول للحصول على أفضل تجربة، أم تفضل الاستمرار في التصفح على الويب؟',
                'open_app' => 'افتح التطبيق',
                'continue_web' => 'استمر على الويب',
                'close' => 'إغلاق'
            )
        );
        
        return isset($translations[$language]) ? $translations[$language] : $translations['en'];
    }
    
    public function activate_plugin() {
        // Set default values if they don't exist
        if (!get_option('app_detector_android_uri')) {
            update_option('app_detector_android_uri', 'myappname://');
        }
        if (!get_option('app_detector_ios_uri')) {
            update_option('app_detector_ios_uri', 'myappname://');
        }
        if (!get_option('app_detector_google_play')) {
            update_option('app_detector_google_play', 'https://play.google.com/store/apps/details?id=your.app.id');
        }
        if (!get_option('app_detector_apple_store')) {
            update_option('app_detector_apple_store', 'https://apps.apple.com/app/your-app-id');
        }
        if (!get_option('app_detector_language')) {
            update_option('app_detector_language', 'en');
        }
        
        // Store plugin version
        update_option('app_detector_version', $this->version);
        
        // Set activation timestamp
        update_option('app_detector_activated', current_time('timestamp'));
    }
    
    public function deactivate_plugin() {
        // Clean up if needed
        // delete_option('app_detector_version'); // Uncomment if you want to remove version on deactivation
    }
    
    public function check_version() {
        $stored_version = get_option('app_detector_version');
        
        if ($stored_version && version_compare($stored_version, $this->version, '<')) {
            // Version has been updated
            $this->update_plugin_version();
        }
    }
    
    public function update_plugin_version() {
        $old_version = get_option('app_detector_version');
        $new_version = $this->version;
        
        // Perform any necessary database updates here
        // This is where you'd handle schema changes, new options, etc.
        
        // Update stored version
        update_option('app_detector_version', $new_version);
        
        // Log the update
        update_option('app_detector_last_update', current_time('timestamp'));
        
        // Show update notice
        add_action('admin_notices', function() use ($old_version, $new_version) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>App Detector</strong> has been updated from version ' . esc_html($old_version) . ' to ' . esc_html($new_version) . '.</p>';
            echo '</div>';
        });
    }
    
    public function get_version() {
        return $this->version;
    }
    
    public function add_admin_menu() {
        add_options_page(
            'App Detector Settings',
            'App Detector',
            'manage_options',
            'app-detector',
            array($this, 'admin_page')
        );
    }
    
    public function register_settings() {
        register_setting('app_detector_options', 'app_detector_android_uri');
        register_setting('app_detector_options', 'app_detector_ios_uri');
        register_setting('app_detector_options', 'app_detector_google_play');
        register_setting('app_detector_options', 'app_detector_apple_store');
        register_setting('app_detector_options', 'app_detector_language');
    }
    
    public function admin_enqueue_scripts($hook) {
        if ($hook !== 'settings_page_app-detector') {
            return;
        }
        
        wp_enqueue_script('app-detector-admin', APP_DETECTOR_PLUGIN_URL . 'admin.js', array('jquery'), $this->version, true);
        wp_localize_script('app-detector-admin', 'appDetectorAdmin', array(
            'version' => $this->version,
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('app_detector_admin_nonce')
        ));
    }
    
    public function admin_page() {
        $current_version = $this->get_version();
        $stored_version = get_option('app_detector_version');
        $activated_date = get_option('app_detector_activated');
        $last_update = get_option('app_detector_last_update');
        $current_language = get_option('app_detector_language', 'en');
        $available_languages = $this->get_available_languages();
        $updates_disabled = get_option('app_detector_updates_disabled', false);
        $ajax_disabled = get_option('app_detector_ajax_disabled', false);
        $update_checker_removed = get_option('app_detector_update_checker_removed', false);
        
        // Handle update toggle actions
        if (isset($_POST['action']) && $_POST['action'] === 'toggle_updates') {
            if (isset($_POST['disable_updates']) && $_POST['disable_updates'] === '1') {
                $this->disable_updates();
                $updates_disabled = true;
                echo '<div class="notice notice-success is-dismissible"><p>Updates have been disabled.</p></div>';
            } elseif (isset($_POST['enable_updates']) && $_POST['enable_updates'] === '1') {
                $this->enable_updates();
                $updates_disabled = false;
                echo '<div class="notice notice-success is-dismissible"><p>Updates have been enabled.</p></div>';
            }
        }
        
        // Handle complete removal of update checker
        if (isset($_POST['action']) && $_POST['action'] === 'remove_update_checker') {
            $this->remove_update_checker();
            echo '<div class="notice notice-warning is-dismissible"><p>Update checker has been completely removed. You may need to deactivate and reactivate the plugin to restore it.</p></div>';
        }
        
        // Handle AJAX handler toggle
        if (isset($_POST['action']) && $_POST['action'] === 'toggle_ajax') {
            if (isset($_POST['disable_ajax']) && $_POST['disable_ajax'] === '1') {
                $this->disable_ajax_handlers();
                echo '<div class="notice notice-success is-dismissible"><p>AJAX handlers have been disabled.</p></div>';
            } elseif (isset($_POST['enable_ajax']) && $_POST['enable_ajax'] === '1') {
                $this->enable_ajax_handlers();
                echo '<div class="notice notice-success is-dismissible"><p>AJAX handlers have been enabled.</p></div>';
            }
        }
        
        ?>
        <div class="wrap">
            <!-- Logo and Header -->
            <div style="display: flex; align-items: center; margin-bottom: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                <div style="margin-right: 20px;">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="48" height="48" rx="8" fill="#007AFF"/>
                        <path d="M12 16C12 13.7909 13.7909 12 16 12H32C34.2091 12 36 13.7909 36 16V32C36 34.2091 34.2091 36 32 36H16C13.7909 36 12 34.2091 12 32V16Z" fill="white"/>
                        <path d="M18 20C18 18.8954 18.8954 18 20 18H28C29.1046 18 30 18.8954 30 20V28C30 29.1046 29.1046 30 28 30H20C18.8954 30 18 29.1046 18 28V20Z" fill="#007AFF"/>
                        <circle cx="24" cy="24" r="2" fill="white"/>
                    </svg>
                </div>
                <div>
                    <h1 style="margin: 0; color: #23282d;">App Detector Settings</h1>
                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Configure your mobile app detection settings</p>
                    <p style="margin: 5px 0 0 0; color: #007AFF; font-size: 12px; font-weight: 500;">Version <?php echo esc_html($current_version); ?></p>
                </div>
            </div>

            <!-- Version Info Box -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #23282d;">Version Information</h3>
                <table style="width: 100%; font-size: 13px;">
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Current Version:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html($current_version); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Stored Version:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html($stored_version ?: 'Not set'); ?></td>
                    </tr>
                    <?php if ($activated_date): ?>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Activated:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html(date('Y-m-d H:i:s', $activated_date)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($last_update): ?>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Last Updated:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html(date('Y-m-d H:i:s', $last_update)); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>

            <!-- Update Server Debug Box -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #23282d;">Update Server Status</h3>
                
                <!-- AJAX Status -->
                <div style="margin-bottom: 15px; padding: 10px; background: #f9f9f9; border-radius: 4px;">
                    <h4 style="margin: 0 0 8px 0; color: #23282d; font-size: 14px;">AJAX Handler Status</h4>
                    <?php if ($ajax_disabled): ?>
                        <div style="color: #ffb900; font-size: 13px; margin-bottom: 8px;">
                            ⚠️ <strong>AJAX handlers are disabled</strong>
                        </div>
                        <form method="post" style="margin-bottom: 8px;">
                            <input type="hidden" name="action" value="toggle_ajax">
                            <input type="hidden" name="enable_ajax" value="1">
                            <?php wp_nonce_field('app_detector_toggle_ajax'); ?>
                            <button type="submit" class="button button-primary">Enable AJAX Handlers</button>
                        </form>
                    <?php else: ?>
                        <div style="color: #46b450; font-size: 13px; margin-bottom: 8px;">
                            ✅ <strong>AJAX handlers are enabled</strong>
                        </div>
                        <form method="post" style="margin-bottom: 8px;">
                            <input type="hidden" name="action" value="toggle_ajax">
                            <input type="hidden" name="disable_ajax" value="1">
                            <?php wp_nonce_field('app_detector_toggle_ajax'); ?>
                            <button type="submit" class="button button-secondary">Disable AJAX Handlers</button>
                        </form>
                    <?php endif; ?>
                </div>
                
                <?php if ($update_checker_removed): ?>
                    <div style="color: #dc3232; font-size: 13px; margin-bottom: 10px;">
                        ❌ <strong>Update checker has been completely removed</strong>
                    </div>
                    <div style="font-size: 12px; color: #666; margin-bottom: 10px;">
                        To restore the update checker, deactivate and reactivate the plugin.
                    </div>
                <?php elseif ($updates_disabled): ?>
                    <div style="color: #ffb900; font-size: 13px; margin-bottom: 10px;">
                        ⚠️ <strong>Updates are currently disabled</strong>
                    </div>
                    <form method="post" style="margin-bottom: 10px;">
                        <input type="hidden" name="action" value="toggle_updates">
                        <input type="hidden" name="enable_updates" value="1">
                        <?php wp_nonce_field('app_detector_toggle_updates'); ?>
                        <button type="submit" class="button button-primary">Enable Updates</button>
                    </form>
                <?php else: ?>
                    <?php 
                    $update_test = $this->test_update_server();
                    if ($update_test['success']): 
                    ?>
                        <div style="color: #46b450; font-size: 13px; margin-bottom: 10px;">
                            ✅ <strong>Update server is accessible</strong>
                        </div>
                        <?php if (isset($update_test['data']['version'])): ?>
                        <div style="font-size: 13px; margin-bottom: 5px;">
                            <strong>Latest version available:</strong> <?php echo esc_html($update_test['data']['version']); ?>
                        </div>
                        <?php endif; ?>
                        <form method="post" style="margin-bottom: 10px;">
                            <input type="hidden" name="action" value="toggle_updates">
                            <input type="hidden" name="disable_updates" value="1">
                            <?php wp_nonce_field('app_detector_toggle_updates'); ?>
                            <button type="submit" class="button button-secondary">Disable Updates</button>
                        </form>
                        
                        <form method="post" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="remove_update_checker">
                            <?php wp_nonce_field('app_detector_remove_updates'); ?>
                            <button type="submit" class="button button-link-delete" onclick="return confirm('This will completely remove the update checker. Are you sure?')">Remove Update Checker Completely</button>
                        </form>
                    <?php else: ?>
                        <div style="color: #dc3232; font-size: 13px; margin-bottom: 10px;">
                            ❌ <strong>Update server connection failed</strong>
                        </div>
                        <div style="font-size: 12px; color: #666; margin-bottom: 5px;">
                            <strong>Error:</strong> <?php echo esc_html($update_test['error']); ?>
                        </div>
                        <?php if (isset($update_test['body'])): ?>
                        <div style="font-size: 12px; color: #666;">
                            <strong>Response:</strong> <?php echo esc_html(substr($update_test['body'], 0, 200)) . (strlen($update_test['body']) > 200 ? '...' : ''); ?>
                        </div>
                        <?php endif; ?>
                        <form method="post" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="toggle_updates">
                            <input type="hidden" name="disable_updates" value="1">
                            <?php wp_nonce_field('app_detector_toggle_updates'); ?>
                            <button type="submit" class="button button-secondary">Disable Updates</button>
                        </form>
                        
                        <form method="post" style="margin-top: 10px;">
                            <input type="hidden" name="action" value="remove_update_checker">
                            <?php wp_nonce_field('app_detector_remove_updates'); ?>
                            <button type="submit" class="button button-link-delete" onclick="return confirm('This will completely remove the update checker. Are you sure?')">Remove Update Checker Completely</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
                <div style="font-size: 12px; color: #666; margin-top: 10px;">
                    <strong>Update URL:</strong> https://ibra-media.github.io/app-detector/info.json
                </div>
            </div>

            <!-- Settings Form -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px;">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('app_detector_options');
                    do_settings_sections('app_detector_options');
                    ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="app_detector_language">Language</label>
                            </th>
                            <td>
                                <select id="app_detector_language" name="app_detector_language">
                                    <?php foreach ($available_languages as $code => $language): ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($current_language, $code); ?>>
                                            <?php echo esc_html($language['native']); ?> (<?php echo esc_html($language['name']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Select the language for the popup messages</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_android_uri">Android App URI Scheme</label>
                            </th>
                            <td>
                                <input type="text" id="app_detector_android_uri" name="app_detector_android_uri" 
                                       value="<?php echo esc_attr(get_option('app_detector_android_uri')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter your Android app's URI scheme (e.g., myappname://)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_ios_uri">iOS App URI Scheme</label>
                            </th>
                            <td>
                                <input type="text" id="app_detector_ios_uri" name="app_detector_ios_uri" 
                                       value="<?php echo esc_attr(get_option('app_detector_ios_uri')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter your iOS app's URI scheme (e.g., myappname://)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_google_play">Google Play Store Link</label>
                            </th>
                            <td>
                                <input type="url" id="app_detector_google_play" name="app_detector_google_play" 
                                       value="<?php echo esc_attr(get_option('app_detector_google_play')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter the Google Play Store link for your app</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_apple_store">Apple App Store Link</label>
                            </th>
                            <td>
                                <input type="url" id="app_detector_apple_store" name="app_detector_apple_store" 
                                       value="<?php echo esc_attr(get_option('app_detector_apple_store')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter the Apple App Store link for your app</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>

            <!-- Footer with Copyright and Contact -->
            <div style="margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; text-align: center;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <div style="flex: 1; text-align: left;">
                        <p style="margin: 0; color: #666; font-size: 13px;">
                            <strong>Copyright © 2025 FikaBytes, made by Marketing and Apps by Silfver</strong>
                        </p>
                    </div>
                    <div style="flex: 1; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 13px;">
                            For technical support and questions:
                        </p>
                    </div>
                    <div style="flex: 1; text-align: right;">
                        <p style="margin: 0; color: #007AFF; font-size: 13px;">
                            <strong>tech@fika.nu</strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('app-detector', APP_DETECTOR_PLUGIN_URL . 'app-detector.js', array(), $this->version, true);
        wp_localize_script('app-detector', 'appDetectorAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('app_detector_nonce'),
            'version' => $this->version
        ));
    }
    
    public function inject_script() {
        $android_uri = get_option('app_detector_android_uri');
        $ios_uri = get_option('app_detector_ios_uri');
        $google_play = get_option('app_detector_google_play');
        $apple_store = get_option('app_detector_apple_store');
        $language = get_option('app_detector_language', 'en');
        $translations = $this->get_translations($language);
        
        ?>
        <script type="text/javascript">
            window.appDetectorConfig = {
                androidUri: '<?php echo esc_js($android_uri); ?>',
                iosUri: '<?php echo esc_js($ios_uri); ?>',
                googlePlay: '<?php echo esc_js($google_play); ?>',
                appleStore: '<?php echo esc_js($apple_store); ?>',
                version: '<?php echo esc_js($this->version); ?>',
                language: '<?php echo esc_js($language); ?>',
                translations: <?php echo json_encode($translations); ?>
            };
        </script>
        <?php
    }

    /**
     * Check for update checker errors
     */
    public function check_update_errors() {
        if (isset($_GET['action']) && $_GET['action'] === 'upgrade-plugin' && 
            isset($_GET['plugin']) && $_GET['plugin'] === 'app-detector/app-detector.php') {
            
            // Check if there was an error during update check
            $update_errors = get_transient('app_detector_update_errors');
            if ($update_errors) {
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>App Detector Update Error:</strong> ' . esc_html($update_errors) . '</p>';
                echo '</div>';
                delete_transient('app_detector_update_errors');
            }
        }
    }

    /**
     * Handle manual update check via AJAX
     */
    public function handle_manual_update_check() {
        // Check if nonce is provided and valid
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'app_detector_admin_nonce')) {
            wp_send_json_error('Invalid nonce. Please refresh the page and try again.');
            exit;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('You do not have sufficient permissions to perform this action.');
            exit;
        }

        try {
            $update_test = $this->test_update_server();

            if ($update_test['success']) {
                wp_send_json_success(array(
                    'message' => 'Update server is accessible.',
                    'version' => isset($update_test['data']['version']) ? $update_test['data']['version'] : 'Unknown'
                ));
            } else {
                wp_send_json_error(array(
                    'message' => 'Update server connection failed.',
                    'error' => $update_test['error']
                ));
            }
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => 'An error occurred while checking for updates.',
                'error' => $e->getMessage()
            ));
        }
        exit;
    }
}

// Initialize the plugin
new AppDetector(); 