<?php
/**
 * Plugin Name: App Detector
 * Description: Detects mobile devices and shows app store links or opens the app if installed
 * Version: 1.0.1
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Author: FikaBytes
 * Author URI: https://fika.nu
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: app-detector
 * Domain Path: /languages
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('APP_DETECTOR_VERSION', '1.0.1');
define('APP_DETECTOR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('APP_DETECTOR_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('APP_DETECTOR_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include the Plugin Update Checker
require_once plugin_dir_path(__FILE__) . 'plugin-update-checker/plugin-update-checker.php';

class AppDetector {
    
    private $version;
    private $updateChecker;
    
    public function __construct() {
        $this->version = APP_DETECTOR_VERSION;
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_head', array($this, 'inject_script'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
        
        // Add version check on admin pages
        add_action('admin_notices', array($this, 'check_version'));
        
        // Initialize update checker
        $this->init_update_checker();
    }
    
    /**
     * Initialize the update checker
     */
    private function init_update_checker() {
        // Only run in admin
        if (!is_admin()) {
            return;
        }
        
        // Initialize the update checker
        $this->updateChecker = Puc_v5_Factory::buildUpdateChecker(
            'https://ibra-media.github.io/app-detector/info.json', // Replace with your actual update server URL
            __FILE__,
            'app-detector'
        );
        
        // Optional: Set authentication if using private repository
        // $this->updateChecker->setAuthentication('your-token-here');
        
        // Optional: Set branch if using Git repository
        // $this->updateChecker->setBranch('main');
        
        // Add custom query arguments
        $this->updateChecker->addQueryArgFilter(array($this, 'update_filter'));
        
        // Add custom download filter
        $this->updateChecker->addDownloadFilter(array($this, 'download_filter'));
    }
    
    /**
     * Custom query argument filter for update requests
     */
    public function update_filter($queryArgs) {
        // Add any custom parameters you want to send with update requests
        $queryArgs['site_url'] = get_site_url();
        $queryArgs['wp_version'] = get_bloginfo('version');
        $queryArgs['plugin_version'] = $this->version;
        $queryArgs['php_version'] = phpversion();
        $queryArgs['locale'] = get_locale();
        
        return $queryArgs;
    }
    
    /**
     * Custom download filter
     */
    public function download_filter($url, $args) {
        // You can modify the download URL or add authentication here
        return $url;
    }
    
    /**
     * Get available languages
     */
    public function get_available_languages() {
        return array(
            'en' => array(
                'name' => 'English',
                'native' => 'English'
            ),
            'ar' => array(
                'name' => 'Arabic',
                'native' => 'العربية'
            )
        );
    }
    
    /**
     * Get translations for a specific language
     */
    public function get_translations($language = 'en') {
        $translations = array(
            'en' => array(
                'popup_title' => 'Open App or Continue on Web',
                'popup_description' => 'Would you like to open our mobile app for the best experience, or continue browsing on the web?',
                'open_app' => 'Open App',
                'continue_web' => 'Continue on Web',
                'close' => 'Close'
            ),
            'ar' => array(
                'popup_title' => 'افتح التطبيق أو استمر على الويب',
                'popup_description' => 'هل تريد فتح تطبيقنا المحمول للحصول على أفضل تجربة، أم تفضل الاستمرار في التصفح على الويب؟',
                'open_app' => 'افتح التطبيق',
                'continue_web' => 'استمر على الويب',
                'close' => 'إغلاق'
            )
        );
        
        return isset($translations[$language]) ? $translations[$language] : $translations['en'];
    }
    
    public function activate_plugin() {
        // Set default values if they don't exist
        if (!get_option('app_detector_android_uri')) {
            update_option('app_detector_android_uri', 'myappname://');
        }
        if (!get_option('app_detector_ios_uri')) {
            update_option('app_detector_ios_uri', 'myappname://');
        }
        if (!get_option('app_detector_google_play')) {
            update_option('app_detector_google_play', 'https://play.google.com/store/apps/details?id=your.app.id');
        }
        if (!get_option('app_detector_apple_store')) {
            update_option('app_detector_apple_store', 'https://apps.apple.com/app/your-app-id');
        }
        if (!get_option('app_detector_language')) {
            update_option('app_detector_language', 'en');
        }
        
        // Store plugin version
        update_option('app_detector_version', $this->version);
        
        // Set activation timestamp
        update_option('app_detector_activated', current_time('timestamp'));
    }
    
    public function deactivate_plugin() {
        // Clean up if needed
        // delete_option('app_detector_version'); // Uncomment if you want to remove version on deactivation
    }
    
    public function check_version() {
        $stored_version = get_option('app_detector_version');
        
        if ($stored_version && version_compare($stored_version, $this->version, '<')) {
            // Version has been updated
            $this->update_plugin_version();
        }
    }
    
    public function update_plugin_version() {
        $old_version = get_option('app_detector_version');
        $new_version = $this->version;
        
        // Perform any necessary database updates here
        // This is where you'd handle schema changes, new options, etc.
        
        // Update stored version
        update_option('app_detector_version', $new_version);
        
        // Log the update
        update_option('app_detector_last_update', current_time('timestamp'));
        
        // Show update notice
        add_action('admin_notices', function() use ($old_version, $new_version) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>App Detector</strong> has been updated from version ' . esc_html($old_version) . ' to ' . esc_html($new_version) . '.</p>';
            echo '</div>';
        });
    }
    
    public function get_version() {
        return $this->version;
    }
    
    public function add_admin_menu() {
        add_options_page(
            'App Detector Settings',
            'App Detector',
            'manage_options',
            'app-detector',
            array($this, 'admin_page')
        );
    }
    
    public function register_settings() {
        register_setting('app_detector_options', 'app_detector_android_uri');
        register_setting('app_detector_options', 'app_detector_ios_uri');
        register_setting('app_detector_options', 'app_detector_google_play');
        register_setting('app_detector_options', 'app_detector_apple_store');
        register_setting('app_detector_options', 'app_detector_language');
    }
    
    public function admin_enqueue_scripts($hook) {
        if ($hook !== 'settings_page_app-detector') {
            return;
        }
        
        wp_enqueue_script('app-detector-admin', APP_DETECTOR_PLUGIN_URL . 'admin.js', array('jquery'), $this->version, true);
        wp_localize_script('app-detector-admin', 'appDetectorAdmin', array(
            'version' => $this->version,
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('app_detector_admin_nonce')
        ));
    }
    
    public function admin_page() {
        $current_version = $this->get_version();
        $stored_version = get_option('app_detector_version');
        $activated_date = get_option('app_detector_activated');
        $last_update = get_option('app_detector_last_update');
        $current_language = get_option('app_detector_language', 'en');
        $available_languages = $this->get_available_languages();
        
        ?>
        <div class="wrap">
            <!-- Logo and Header -->
            <div style="display: flex; align-items: center; margin-bottom: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                <div style="margin-right: 20px;">
                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="48" height="48" rx="8" fill="#007AFF"/>
                        <path d="M12 16C12 13.7909 13.7909 12 16 12H32C34.2091 12 36 13.7909 36 16V32C36 34.2091 34.2091 36 32 36H16C13.7909 36 12 34.2091 12 32V16Z" fill="white"/>
                        <path d="M18 20C18 18.8954 18.8954 18 20 18H28C29.1046 18 30 18.8954 30 20V28C30 29.1046 29.1046 30 28 30H20C18.8954 30 18 29.1046 18 28V20Z" fill="#007AFF"/>
                        <circle cx="24" cy="24" r="2" fill="white"/>
                    </svg>
                </div>
                <div>
                    <h1 style="margin: 0; color: #23282d;">App Detector Settings</h1>
                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Configure your mobile app detection settings</p>
                    <p style="margin: 5px 0 0 0; color: #007AFF; font-size: 12px; font-weight: 500;">Version <?php echo esc_html($current_version); ?></p>
                </div>
            </div>

            <!-- Version Info Box -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; color: #23282d;">Version Information</h3>
                <table style="width: 100%; font-size: 13px;">
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Current Version:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html($current_version); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Stored Version:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html($stored_version ?: 'Not set'); ?></td>
                    </tr>
                    <?php if ($activated_date): ?>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Activated:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html(date('Y-m-d H:i:s', $activated_date)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if ($last_update): ?>
                    <tr>
                        <td style="padding: 5px 0; color: #666;"><strong>Last Updated:</strong></td>
                        <td style="padding: 5px 0; color: #23282d;"><?php echo esc_html(date('Y-m-d H:i:s', $last_update)); ?></td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>

            <!-- Settings Form -->
            <div style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px;">
                <form method="post" action="options.php">
                    <?php
                    settings_fields('app_detector_options');
                    do_settings_sections('app_detector_options');
                    ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="app_detector_language">Language</label>
                            </th>
                            <td>
                                <select id="app_detector_language" name="app_detector_language">
                                    <?php foreach ($available_languages as $code => $language): ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($current_language, $code); ?>>
                                            <?php echo esc_html($language['native']); ?> (<?php echo esc_html($language['name']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Select the language for the popup messages</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_android_uri">Android App URI Scheme</label>
                            </th>
                            <td>
                                <input type="text" id="app_detector_android_uri" name="app_detector_android_uri" 
                                       value="<?php echo esc_attr(get_option('app_detector_android_uri')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter your Android app's URI scheme (e.g., myappname://)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_ios_uri">iOS App URI Scheme</label>
                            </th>
                            <td>
                                <input type="text" id="app_detector_ios_uri" name="app_detector_ios_uri" 
                                       value="<?php echo esc_attr(get_option('app_detector_ios_uri')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter your iOS app's URI scheme (e.g., myappname://)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_google_play">Google Play Store Link</label>
                            </th>
                            <td>
                                <input type="url" id="app_detector_google_play" name="app_detector_google_play" 
                                       value="<?php echo esc_attr(get_option('app_detector_google_play')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter the Google Play Store link for your app</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="app_detector_apple_store">Apple App Store Link</label>
                            </th>
                            <td>
                                <input type="url" id="app_detector_apple_store" name="app_detector_apple_store" 
                                       value="<?php echo esc_attr(get_option('app_detector_apple_store')); ?>" 
                                       class="regular-text" />
                                <p class="description">Enter the Apple App Store link for your app</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>

            <!-- Footer with Copyright and Contact -->
            <div style="margin-top: 20px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; text-align: center;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <div style="flex: 1; text-align: left;">
                        <p style="margin: 0; color: #666; font-size: 13px;">
                            <strong>Copyright © 2025 FikaBytes, made by Marketing and Apps by Silfver</strong>
                        </p>
                    </div>
                    <div style="flex: 1; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 13px;">
                            For technical support and questions:
                        </p>
                    </div>
                    <div style="flex: 1; text-align: right;">
                        <p style="margin: 0; color: #007AFF; font-size: 13px;">
                            <strong>tech@fika.nu</strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('app-detector', APP_DETECTOR_PLUGIN_URL . 'app-detector.js', array(), $this->version, true);
        wp_localize_script('app-detector', 'appDetectorAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('app_detector_nonce'),
            'version' => $this->version
        ));
    }
    
    public function inject_script() {
        $android_uri = get_option('app_detector_android_uri');
        $ios_uri = get_option('app_detector_ios_uri');
        $google_play = get_option('app_detector_google_play');
        $apple_store = get_option('app_detector_apple_store');
        $language = get_option('app_detector_language', 'en');
        $translations = $this->get_translations($language);
        
        ?>
        <script type="text/javascript">
            window.appDetectorConfig = {
                androidUri: '<?php echo esc_js($android_uri); ?>',
                iosUri: '<?php echo esc_js($ios_uri); ?>',
                googlePlay: '<?php echo esc_js($google_play); ?>',
                appleStore: '<?php echo esc_js($apple_store); ?>',
                version: '<?php echo esc_js($this->version); ?>',
                language: '<?php echo esc_js($language); ?>',
                translations: <?php echo json_encode($translations); ?>
            };
        </script>
        <?php
    }
}

// Initialize the plugin
new AppDetector(); 