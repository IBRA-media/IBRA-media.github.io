# App Detector WordPress Plugin

A WordPress plugin that detects mobile devices and shows appropriate app store links or opens the app if it's installed.

## Version Information

- **Current Version**: 1.0.1
- **Requires WordPress**: 5.0 or higher
- **Tested up to**: 6.4
- **Requires PHP**: 7.4 or higher

## Changelog

### Version 1.0.1 (2025-07-29)
- Initial release
- Mobile device detection
- App installation detection
- Smart popup system
- Session-based popup dismissal
- Admin configuration interface
- Version control system
- Update notifications
- Translations

## Features

- **Admin Interface**: Configure your app URI scheme and store links
- **Device Detection**: Automatically detects iOS and Android devices
- **App Detection**: Checks if your app is installed using URI scheme
- **Smart Popups**: Shows appropriate buttons based on app installation status
- **Responsive Design**: Modern, mobile-friendly popup interface
- **Version Control**: Built-in version management and update system

## Installation

1. Upload the plugin files to your WordPress site's `/wp-content/plugins/app-detector/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings > App Detector to configure your app settings

## Configuration

In the WordPress admin, navigate to **Settings > App Detector** and configure:

1. **Android App URI Scheme**: Your Android app's custom URI scheme (e.g., `myappname://`)
2. **iOS App URI Scheme**: Your iOS app's custom URI scheme (e.g., `myappname://`)
3. **Google Play Store Link**: The link to your app on Google Play Store
4. **Apple App Store Link**: The link to your app on Apple App Store

## How It Works

### For Desktop Users
- No popup is shown
- Plugin does nothing

### For Mobile Users (iOS/Android)

#### If App is Installed:
- Shows a popup with "Open App" and "Close" buttons
- "Open App" button opens your app using the configured URI scheme
- "Close" button dismisses the popup

#### If App is Not Installed:
- Shows a popup with "Download App" and "Close" buttons
- "Download App" button opens the appropriate app store (Google Play for Android, Apple App Store for iOS)
- "Close" button dismisses the popup

## Technical Details

- **Device Detection**: Uses user agent string to detect mobile devices
- **App Detection**: Uses iframe method to test if app URI scheme is available
- **Popup Timing**: Popup appears 1 second after page load to ensure smooth user experience
- **Responsive**: Popup is designed to work well on all mobile screen sizes
- **Version Control**: Automatic version management with update notifications

## File Structure

```
app-detector/
├── app-detector.php    # Main plugin file
├── app-detector.js     # JavaScript for device detection and popups
├── admin.js           # Admin interface JavaScript
└── README.md          # This file
```

## Customization

The popup styling is handled inline in the JavaScript file. You can modify the CSS styles in the `showPopup()` function to match your site's design.

## Browser Compatibility

- iOS Safari (iPhone/iPad)
- Android Chrome
- Android Firefox
- Other mobile browsers

## Notes

- The app detection method uses a timeout-based approach since direct app detection isn't always reliable
- The plugin only runs on mobile devices to avoid unnecessary processing on desktop
- Popup can be dismissed by clicking outside of it or using the close button
- Version information is displayed in the admin interface

## Support

For issues or questions, please check the WordPress plugin repository or contact the plugin author.

---

**Copyright © 2025 FikaBytes, made by Marketing and Apps by Silfver**

For technical support and questions, please contact: **tech@fika.nu** 